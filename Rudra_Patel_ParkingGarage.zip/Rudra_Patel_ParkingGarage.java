/*
	Program:		Rudra_Patel_ParkingGarage.java
	Purpose:		parking location
	Author:			Rudra Patel
	Date:			Nov 17, 2022
*/
import java.util.Scanner;

public class Rudra_Patel_ParkingGarage {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("This is Rudra's Parking Garage Assistant");
        System.out.println("This program will make it easy for a driver to find and return to their" +
                "\nvehicle if it is parked somewhere in the parking garage.");

        String[] level_Info = {"underground", "ground", "second", "third", "fourth", "fifth", "roof",};
        String[] area_Info = {"west side elevator", "northwest corner", "northeast corner", "northeast corner"
                , "southwest corner", "east side elevator"};
        System.out.println("\nThis parking garage is divided into the following parking areas...\n");
        for (String s : area_Info) {
            System.out.println(s);
        }
        System.out.println("\nOn the following levels...\n");
        for (String s : level_Info) {
            System.out.println(s);
        }
        System.out.print("\nEnter the 2-character zone code where you left your vehicle: ");
        String vehiclePosition = input.nextLine();
        char[] vehiclePosition_R_W = vehiclePosition.toUpperCase().toCharArray();
        int level_W_R = (int)vehiclePosition_R_W[0];
        int area_Info_W_R = (int)vehiclePosition_R_W[1];
        System.out.println(level_W_R);
        System.out.println(area_Info_W_R);
        String[] parking_At = new String[2];
        if((level_W_R <49 || area_Info_W_R<65 || level_W_R>55 || area_Info_W_R>70))
        {
            System.out.println("That zone code does not exist. Try again when you know the correct code.");
        }
        else {
            switch (level_W_R) {
                case 49 -> parking_At[0] = level_Info[0];
                case 50 -> parking_At[0] = level_Info[1];
                case 51 -> parking_At[0] = level_Info[2];
                case 52 -> parking_At[0] = level_Info[3];
                case 53 -> parking_At[0] = level_Info[4];
                case 54 -> parking_At[0] = level_Info[5];
                case 55 -> parking_At[0] = level_Info[6];
            }
            switch (area_Info_W_R) {
                case 65 -> parking_At[1] = area_Info[0];
                case 66 -> parking_At[1] = area_Info[1];
                case 67 -> parking_At[1] = area_Info[2];
                case 68 -> parking_At[1] = area_Info[3];
                case 69 -> parking_At[1] = area_Info[4];
                case 70 -> parking_At[1] = area_Info[5];
            }
            System.out.println("\nYou are parked on the "+parking_At[0]+" level at the "+parking_At[1]+".\n");
        }

        input.close();
    }//end method
}//end main